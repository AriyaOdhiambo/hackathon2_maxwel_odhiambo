import React from 'react';
import { Brain, User, ArrowLeft } from 'lucide-react';

interface HeaderProps {
  user: any;
  onShowAuth: () => void;
  onBackToInput: () => void;
  showBackButton: boolean;
}

export const Header: React.FC<HeaderProps> = ({ 
  user, 
  onShowAuth, 
  onBackToInput, 
  showBackButton 
}) => {
  return (
    <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {showBackButton && (
            <button
              onClick={onBackToInput}
              className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </button>
          )}
          <div className="flex items-center space-x-2">
            <Brain className="w-8 h-8 text-purple-300" />
            <h1 className="text-2xl font-bold text-white">StudyBuddy AI</h1>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <span className="text-white font-medium">{user.email}</span>
            </div>
          ) : (
            <button
              onClick={onShowAuth}
              className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors font-medium"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};