import React, { useState } from 'react';
import { RotateCcw, CheckCircle, Star } from 'lucide-react';
import { Flashcard } from '../types/flashcard';

interface FlashcardComponentProps {
  flashcard: Flashcard;
  isCompleted: boolean;
  onMarkComplete: () => void;
}

export const FlashcardComponent: React.FC<FlashcardComponentProps> = ({
  flashcard,
  isCompleted,
  onMarkComplete
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-400 bg-green-400/10';
      case 'medium': return 'text-yellow-400 bg-yellow-400/10';
      case 'hard': return 'text-red-400 bg-red-400/10';
      default: return 'text-purple-400 bg-purple-400/10';
    }
  };

  const getDifficultyStars = (difficulty: string) => {
    const count = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 2 : 3;
    return Array.from({ length: 3 }, (_, i) => (
      <Star 
        key={i} 
        className={`w-4 h-4 ${i < count ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} 
      />
    ));
  };

  return (
    <div className="perspective-1000 w-full max-w-2xl mx-auto">
      <div 
        className={`relative w-full h-96 transition-transform duration-700 preserve-3d cursor-pointer ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
        onClick={handleFlip}
      >
        {/* Front of card - Question */}
        <div className="absolute inset-0 w-full h-full backface-hidden">
          <div className="bg-gradient-to-br from-white/15 to-white/5 backdrop-blur-lg rounded-2xl p-8 h-full border border-white/20 flex flex-col justify-between shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getDifficultyColor(flashcard.difficulty)}`}>
                {flashcard.difficulty.toUpperCase()}
              </span>
              <div className="flex items-center space-x-1">
                {getDifficultyStars(flashcard.difficulty)}
              </div>
            </div>
            
            <div className="flex-1 flex items-center justify-center text-center">
              <h3 className="text-2xl font-bold text-white leading-relaxed">
                {flashcard.question}
              </h3>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-purple-300">
                <RotateCcw className="w-4 h-4" />
                <span className="text-sm">Click to reveal answer</span>
              </div>
              {isCompleted && (
                <CheckCircle className="w-6 h-6 text-green-400 fill-current" />
              )}
            </div>
          </div>
        </div>

        {/* Back of card - Answer */}
        <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180">
          <div className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-lg rounded-2xl p-8 h-full border border-purple-300/30 flex flex-col justify-between shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-400/20 text-purple-300">
                ANSWER
              </span>
              <div className="flex items-center space-x-1">
                {getDifficultyStars(flashcard.difficulty)}
              </div>
            </div>
            
            <div className="flex-1 flex items-center justify-center text-center">
              <p className="text-xl text-white leading-relaxed">
                {flashcard.answer}
              </p>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-purple-300">
                <RotateCcw className="w-4 h-4" />
                <span className="text-sm">Click to see question</span>
              </div>
              {!isCompleted && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onMarkComplete();
                  }}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-500 hover:bg-green-600 rounded-lg transition-colors text-white font-medium"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Got it!</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};