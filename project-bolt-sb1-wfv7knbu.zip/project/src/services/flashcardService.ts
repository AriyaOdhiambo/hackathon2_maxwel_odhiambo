import { Flashcard } from '../types/flashcard';

// Mock Hugging Face API integration
export const generateFlashcards = async (notes: string): Promise<Flashcard[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  // Mock AI-generated flashcards based on notes
  const mockFlashcards: Flashcard[] = [
    {
      id: '1',
      question: 'What is the primary concept discussed in the study material?',
      answer: 'Based on your notes, the main concept appears to be the fundamental principles and their practical applications.',
      difficulty: 'medium' as const,
      category: 'Core Concepts'
    },
    {
      id: '2',
      question: 'How would you explain the key methodology mentioned in the notes?',
      answer: 'The methodology involves systematic analysis and step-by-step implementation of the discussed principles.',
      difficulty: 'hard' as const,
      category: 'Methodology'
    },
    {
      id: '3',
      question: 'What are the main benefits of applying this knowledge?',
      answer: 'The benefits include improved understanding, practical problem-solving skills, and enhanced academic performance.',
      difficulty: 'easy' as const,
      category: 'Applications'
    },
    {
      id: '4',
      question: 'Which critical factors should be considered when implementing these concepts?',
      answer: 'Key factors include context analysis, resource availability, timing considerations, and potential challenges.',
      difficulty: 'hard' as const,
      category: 'Implementation'
    },
    {
      id: '5',
      question: 'What connections can you draw between different elements in your study material?',
      answer: 'The elements are interconnected through shared principles, complementary processes, and mutual dependencies.',
      difficulty: 'medium' as const,
      category: 'Synthesis'
    }
  ];

  return mockFlashcards;
};

// Real Hugging Face integration (for production)
export const generateFlashcardsWithHuggingFace = async (notes: string): Promise<Flashcard[]> => {
  try {
    const response = await fetch('/api/generate-flashcards', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ notes }),
    });
    
    if (!response.ok) {
      throw new Error('Failed to generate flashcards');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error generating flashcards:', error);
    throw error;
  }
};