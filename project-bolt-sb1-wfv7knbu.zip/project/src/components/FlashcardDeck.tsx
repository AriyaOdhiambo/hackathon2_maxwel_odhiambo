import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCcw, CheckCircle } from 'lucide-react';
import { FlashcardComponent } from './FlashcardComponent';
import { Flashcard } from '../types/flashcard';

interface FlashcardDeckProps {
  flashcards: Flashcard[];
}

export const FlashcardDeck: React.FC<FlashcardDeckProps> = ({ flashcards }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [completedCards, setCompletedCards] = useState<Set<number>>(new Set());

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % flashcards.length);
  };

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
  };

  const handleMarkComplete = () => {
    setCompletedCards(prev => new Set([...prev, currentIndex]));
  };

  const resetProgress = () => {
    setCompletedCards(new Set());
    setCurrentIndex(0);
  };

  const progress = (completedCards.size / flashcards.length) * 100;

  return (
    <div className="max-w-4xl mx-auto">
      {/* Progress Header */}
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-8 border border-white/20">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-white">
            Study Session Progress
          </h2>
          <button
            onClick={resetProgress}
            className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-white"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
        </div>
        
        <div className="w-full bg-white/10 rounded-full h-3 mb-2">
          <div 
            className="bg-gradient-to-r from-purple-400 to-pink-400 h-3 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <div className="flex justify-between text-sm text-purple-200">
          <span>{completedCards.size} of {flashcards.length} completed</span>
          <span>{Math.round(progress)}%</span>
        </div>
      </div>

      {/* Flashcard Display */}
      <div className="relative mb-8">
        <FlashcardComponent 
          flashcard={flashcards[currentIndex]}
          isCompleted={completedCards.has(currentIndex)}
          onMarkComplete={handleMarkComplete}
        />
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-center space-x-4">
        <button
          onClick={handlePrevious}
          className="flex items-center space-x-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-white font-medium backdrop-blur-sm"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Previous</span>
        </button>

        <div className="flex items-center space-x-2 px-4 py-2 bg-white/5 rounded-lg text-white">
          <span className="text-sm font-medium">
            {currentIndex + 1} of {flashcards.length}
          </span>
        </div>

        <button
          onClick={handleNext}
          className="flex items-center space-x-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-200 text-white font-medium backdrop-blur-sm"
        >
          <span>Next</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Study Statistics */}
      {completedCards.size > 0 && (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 text-center border border-white/20">
            <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{completedCards.size}</div>
            <div className="text-sm text-purple-200">Cards Mastered</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 text-center border border-white/20">
            <BookOpen className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{flashcards.length - completedCards.size}</div>
            <div className="text-sm text-purple-200">Cards Remaining</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 text-center border border-white/20">
            <Brain className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{Math.round(progress)}%</div>
            <div className="text-sm text-purple-200">Completion Rate</div>
          </div>
        </div>
      )}
    </div>
  );
};