import React, { useState } from 'react';
import { Sparkles, BookOpen, Zap, Brain } from 'lucide-react';

interface NotesInputProps {
  onGenerate: (notes: string) => void;
}

export const NotesInput: React.FC<NotesInputProps> = ({ onGenerate }) => {
  const [notes, setNotes] = useState('');
  const [isValid, setIsValid] = useState(false);

  const handleNotesChange = (value: string) => {
    setNotes(value);
    setIsValid(value.trim().length >= 100);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      onGenerate(notes);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-white mb-4">
          Transform Your Notes into 
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
            {' '}Interactive Flashcards
          </span>
        </h2>
        <p className="text-xl text-purple-200 mb-8">
          Paste your study notes and let AI create personalized quiz questions for better retention
        </p>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label className="block text-white font-semibold mb-3 text-lg">
              <BookOpen className="w-5 h-5 inline mr-2" />
              Your Study Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder="Paste your study notes here... (minimum 100 characters for best results)"
              className="w-full h-64 p-4 bg-white/5 border border-white/20 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent resize-none"
              maxLength={5000}
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-purple-200">
                {notes.length}/5000 characters
              </span>
              {notes.length >= 100 && (
                <span className="text-sm text-green-400 flex items-center">
                  <Zap className="w-4 h-4 mr-1" />
                  Ready to generate!
                </span>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={!isValid}
            className={`w-full py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-300 flex items-center justify-center space-x-2 ${
              isValid
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1'
                : 'bg-gray-600 text-gray-300 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span>Generate AI Flashcards</span>
          </button>
        </form>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Brain className="w-6 h-6 text-purple-300" />
            </div>
            <h3 className="text-white font-semibold mb-2">AI-Powered</h3>
            <p className="text-purple-200 text-sm">Advanced AI analyzes your notes to create meaningful questions</p>
          </div>
          
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <Zap className="w-6 h-6 text-blue-300" />
            </div>
            <h3 className="text-white font-semibold mb-2">Instant Generation</h3>
            <p className="text-purple-200 text-sm">Get 5 personalized flashcards in seconds</p>
          </div>
          
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-green-300" />
            </div>
            <h3 className="text-white font-semibold mb-2">Smart Learning</h3>
            <p className="text-purple-200 text-sm">Interactive cards that adapt to your learning style</p>
          </div>
        </div>
      </div>
    </div>
  );
};