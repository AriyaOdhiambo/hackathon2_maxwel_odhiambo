import React from 'react';
import { Brain, Sparkles } from 'lucide-react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 text-center max-w-md mx-4">
        <div className="relative mb-6">
          <Brain className="w-16 h-16 text-purple-400 mx-auto animate-pulse" />
          <Sparkles className="w-6 h-6 text-yellow-400 absolute top-0 right-1/3 animate-bounce" />
        </div>
        
        <h3 className="text-2xl font-bold text-white mb-2">
          AI is Working Its Magic
        </h3>
        
        <p className="text-purple-200 mb-6">
          Analyzing your notes and generating personalized flashcards...
        </p>
        
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
            <span className="text-white text-sm">Processing study notes</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse animation-delay-200" />
            <span className="text-white text-sm">Generating quiz questions</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse animation-delay-400" />
            <span className="text-white text-sm">Creating interactive flashcards</span>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="w-full bg-white/10 rounded-full h-2">
            <div className="bg-gradient-to-r from-purple-400 to-pink-400 h-2 rounded-full animate-pulse" style={{ width: '60%' }} />
          </div>
        </div>
      </div>
    </div>
  );
};