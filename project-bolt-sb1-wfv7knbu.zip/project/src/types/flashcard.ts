export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category?: string;
  created_at?: string;
  user_id?: string;
}

export interface GenerateFlashcardsRequest {
  notes: string;
  count?: number;
}