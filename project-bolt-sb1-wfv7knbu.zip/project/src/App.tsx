import React, { useState, useEffect } from 'react';
import { Brain, Plus, BookOpen, Settings, User } from 'lucide-react';
import { Header } from './components/Header';
import { NotesInput } from './components/NotesInput';
import { FlashcardDeck } from './components/FlashcardDeck';
import { LoadingSpinner } from './components/LoadingSpinner';
import { AuthModal } from './components/AuthModal';
import { Flashcard } from './types/flashcard';
import { generateFlashcards } from './services/flashcardService';

function App() {
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showNotesInput, setShowNotesInput] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [user, setUser] = useState(null);

  const handleGenerateFlashcards = async (notes: string) => {
    setIsGenerating(true);
    try {
      const newFlashcards = await generateFlashcards(notes);
      setFlashcards(newFlashcards);
      setShowNotesInput(false);
    } catch (error) {
      console.error('Failed to generate flashcards:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleBackToInput = () => {
    setShowNotesInput(true);
    setFlashcards([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <Header 
        user={user}
        onShowAuth={() => setShowAuth(true)}
        onBackToInput={handleBackToInput}
        showBackButton={!showNotesInput}
      />
      
      <main className="container mx-auto px-4 py-8">
        {isGenerating && <LoadingSpinner />}
        
        {!isGenerating && showNotesInput && (
          <NotesInput onGenerate={handleGenerateFlashcards} />
        )}
        
        {!isGenerating && !showNotesInput && flashcards.length > 0 && (
          <FlashcardDeck flashcards={flashcards} />
        )}
      </main>

      {showAuth && (
        <AuthModal 
          onClose={() => setShowAuth(false)}
          onAuth={setUser}
        />
      )}
    </div>
  );
}

export default App;